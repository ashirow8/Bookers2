# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'b085ed73b90e23d66af04bf37355e413b037f282331e11a3041abcfd74da06d381012ea895e489642b8e154581d971f6081214f993686982ba68e08ffda5ad4c'
